import { SecretVaultWrapper } from 'nillion-sv-wrappers';
import { v4 as uuidv4 } from 'uuid';
import { orgConfig } from './nillionOrgConfig.js';

const SCHEMA_ID = 'b5bc0c08-52a0-4a17-8d77-4c80031da21c';

/**
 * Function to store contract data in Nillion SecretVault
 * @param {string} contractType - Type of the contract
 * @param {string} contractDescription - Description/details of the contract
 * @param {string} contractContent - Generated contract text
 */
async function storeContract(contractType, contractDescription, contractContent) {
  try {
    // Initialize SecretVault collection
    const collection = new SecretVaultWrapper(orgConfig.nodes, orgConfig.orgCredentials, SCHEMA_ID);
    await collection.init();

    // Format the contract data for storage
    const contractData = [
      {
        contract_type: { $allot: contractType },
        contract_description: { $allot: contractDescription },
        contract_content: { $allot: contractContent },
      },
    ];

    // Store contract in SecretVault
    const dataWritten = await collection.writeToNodes(contractData);
    console.log('✅ Contract stored successfully in SecretVault:', JSON.stringify(dataWritten, null, 2));

    // Retrieve and return stored record IDs
    const newIds = [...new Set(dataWritten.map((item) => item.result.data.created).flat())];
    return newIds[0]; // Returning the first document ID
  } catch (error) {
    console.error('❌ Error storing contract:', error.message);
    throw new Error('Failed to store contract in SecretVault.');
  }
}

/**
 * Function to retrieve contract from Nillion SecretVault
 * @param {string} documentId - ID of the stored contract document
 */
async function retrieveContract(documentId) {
  try {
    // Initialize SecretVault collection
    const collection = new SecretVaultWrapper(orgConfig.nodes, orgConfig.orgCredentials, SCHEMA_ID);
    await collection.init();

    // Retrieve contract data using document ID
    const retrievedData = await collection.readFromNodes({ document_id: documentId });

    if (!retrievedData || retrievedData.length === 0) {
      throw new Error('No contract found.');
    }

    console.log('📜 Contract retrieved successfully:', JSON.stringify(retrievedData, null, 2));
    return retrievedData;
  } catch (error) {
    console.error('❌ Error retrieving contract:', error.message);
    throw new Error('Failed to retrieve contract.');
  }
}

// Example usage (for testing)
async function main() {
  try {
    console.log("🚀 Storing a new contract...");
    const contractId = await storeContract(
      "NDA Agreement",
      "Non-Disclosure Agreement between two parties.",
      "This NDA contract states that..."
    );
    console.log("🆔 Stored Contract ID:", contractId);

    console.log("\n🔍 Retrieving contract...");
    const retrievedContract = await retrieveContract(contractId);
    console.log("📂 Retrieved Contract Data:", retrievedContract);
  } catch (error) {
    console.error('❌ SecretVaultWrapper error:', error.message);
    process.exit(1);
  }
}

main();
