

# ✅ Nillion API Credentials
NILLION_API_KEY=e9ab4da72fbe773c396a314783b9df7aa69fda498771c4b2f30a91c23756553a
NILLION_ORG_DID=did:nil:testnet:nillion1k7szskzehl5anw4u9d7s3px08zj3ynf2fun9m4
NILLION_PUBLIC_KEY=03ec9baaaf1a7099068a9d15d3c33c711bb86a05598b8fd302f324b09aa3b3ce5d
NILLION_SECRET_KEY=e9ab4da72fbe773c396a314783b9df7aa69fda498771c4b2f30a91c23756553a

# ✅ Nillion Nodes Configuration (Replace with correct node URLs)


# ✅ Nillion Schema ID (Create in Nillion if not yet done)
NILLION_SCHEMA_ID=your_schema_id_here  # Replace with actual schema ID

# ✅ Server Configuration
PORT=5002

node postSchema.js